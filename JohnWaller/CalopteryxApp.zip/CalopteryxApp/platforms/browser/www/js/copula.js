


document.getElementById("save").addEventListener("click", writeFile);
document.getElementById("reset").addEventListener("click", reset);


function reset() {
}


function writeFile() {

var sectionRadios = document.getElementsByName('r1');
for (var i = 0, length = sectionRadios.length; i < length; i++) {
if (sectionRadios[i].checked) {
section = sectionRadios[i].value;
break;
}
}

var copulaRadios = document.getElementsByName('r2');
for (var i = 0, length = copulaRadios.length; i < length; i++) {
if (copulaRadios[i].checked) {
copula = copulaRadios[i].value;
break;
}
}


var ele = document.getElementsByName("r1");
for(var i=0;i<ele.length;i++) {
  ele[i].checked = false;
}

var ele = document.getElementsByName("r2");
for(var i=0;i<ele.length;i++) {
  ele[i].checked = false;
}


console.log(section);
console.log(copula);

var dateObj = new Date();
newdate =  dateObj.toLocaleString();

var dateObj = new Date();
newdate =  dateObj.toLocaleString();

var messageData = "copula" + ";" + section + ";" + copula + ";" + newdate + "\n";


var type = window.TEMPORARY;
var size = 5*1024*1024;
window.requestFileSystem(type, size, successCallback, errorCallback)
function successCallback(fs) {

fs.root.getFile('log.txt', {create: true}, function(fileEntry) {


fileEntry.createWriter(function(fileWriter) {
fileWriter.onwriteend = function(e) {
alert('Write completed: ' + messageData);
};

fileWriter.onerror = function(e) {
alert('Write failed: ' + e.toString());
};

var blob = new Blob([messageData], {type: 'text/plain'});
fileWriter.seek(fileWriter.length);
fileWriter.write(blob);
}, errorCallback);

}, errorCallback);

}

function errorCallback(error) {
alert("ERROR: " + error.code)
}

}

