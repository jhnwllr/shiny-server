
document.getElementById("copper").addEventListener("click", copperFun);
document.getElementById("darkBlue").addEventListener("click", darkBlueFun);
document.getElementById("lightBlue").addEventListener("click", lightBlueFun);
document.getElementById("yellow").addEventListener("click", yellowFun);
document.getElementById("red").addEventListener("click", redFun);
document.getElementById("violet").addEventListener("click", violetFun);
document.getElementById("green").addEventListener("click", greenFun);
document.getElementById("silver").addEventListener("click", silverFun);
document.getElementById("mint").addEventListener("click", mintFun);
document.getElementById("ocre").addEventListener("click", ocreFun);
document.getElementById("umber").addEventListener("click", umberFun);
document.getElementById("white").addEventListener("click", whiteFun);
document.getElementById("pink").addEventListener("click", pinkFun);
document.getElementById("flesh").addEventListener("click", fleshFun);

document.getElementById("writeFile").addEventListener("click", writeFile);
document.getElementById("Reset").addEventListener("click", reset);




var arr = []
function copperFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("copper").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}

function darkBlueFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("darkBlue").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}

function lightBlueFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("lightBlue").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}

function yellowFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("yellow").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}


function redFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("red").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}

function violetFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("violet").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}

function greenFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("green").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}

function silverFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("silver").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}

function mintFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("mint").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}

function ocreFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("ocre").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}

function umberFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("umber").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}

function whiteFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("white").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}

function pinkFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("pink").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}

function fleshFun() {
navigator.vibrate(30); // add feedback
if(arr.length < 3) {
color = document.getElementById("flesh").value;
arr.push(color);
console.log(arr);
document.getElementById("colorCode").innerHTML = arr.join("");
} else {
alert('color code cannot be greater than 3');
}

}

function reset() {
arr = []
document.getElementById("colorCode").innerHTML = "enter color code";
}


function writeFile() {

var radios = document.getElementsByName('r1');
for (var i = 0, length = radios.length; i < length; i++) {
if (radios[i].checked) {
age = radios[i].value;
break;
}
}

console.log(age);

var dateObj = new Date();
newdate =  dateObj.toLocaleString();

var dateObj = new Date();
newdate =  dateObj.toLocaleString();

var messageData = "age" + ";" + arr.join("") + ";" + age +";"+ newdate + "\n";
arr = []
document.getElementById("colorCode").innerHTML = "enter color code";

var type = window.TEMPORARY;
var size = 5*1024*1024;
window.requestFileSystem(type, size, successCallback, errorCallback)
function successCallback(fs) {

fs.root.getFile('log.txt', {create: true}, function(fileEntry) {


fileEntry.createWriter(function(fileWriter) {
fileWriter.onwriteend = function(e) {
alert('Write completed: ' + messageData);
};

fileWriter.onerror = function(e) {
alert('Write failed: ' + e.toString());
};

var blob = new Blob([messageData], {type: 'text/plain'});
fileWriter.seek(fileWriter.length);
fileWriter.write(blob);
}, errorCallback);

}, errorCallback);

}

function errorCallback(error) {
alert("ERROR: " + error.code)
}

}
