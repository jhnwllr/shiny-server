
document.getElementById("createFile").addEventListener("click", createFile);
document.getElementById("readFile").addEventListener("click", readFile);
document.getElementById("removeFile").addEventListener("click", removeFile);
document.getElementById("sendEmail").addEventListener("click", sendEmail);

	
function sendEmail() {

window.plugin.email.open({
to:     ['calopteryxdata@gmail.com','jhnwllr@gmail.com'],
subject: 'Calopteryx Data File',
body:    messageData,
});

};


var fs = require('fs');		
	
function createFile() {
var type = window.TEMPORARY;
var size = 5*1024*1024;

window.requestFileSystem(type, size, successCallback, errorCallback)

function successCallback(fs) {
fs.root.getFile('log.txt', {create: true, exclusive: true}, function(fileEntry) {
alert('File creation successfull!')
}, errorCallback);
}

console.log("TACO2");
function errorCallback(error) {
alert("ERROR: " + error.code)
}

}



function successCallback(fs) {

	fs.root.getFile('log.txt', {}, function(fileEntry) {
	
	fileEntry.file(function(file) {
	var reader = new FileReader();

	reader.onloadend = function(e) {
	var txtArea = document.getElementById('textarea');
	txtArea.value = this.result;
	messageData = this.result;
	console.log(messageData);
	};

    reader.readAsText(file);

    }, errorCallback);
	}, errorCallback);
   
   }

function errorCallback(error) {
  alert("ERROR: " + error.code)
}

function readFile() {
var type = window.TEMPORARY;
var size = 5*1024*1024;
window.requestFileSystem(type, size, successCallback, errorCallback)
console.log(fs);


successCallback(fs);
		
}

function removeFile() {

if(confirm('Are you sure you want to delete?')) {
   
   var type = window.TEMPORARY;
   var size = 5*1024*1024;

   window.requestFileSystem(type, size, successCallback, errorCallback)

   function successCallback(fs) {
      fs.root.getFile('log.txt', {create: false}, function(fileEntry) {

         fileEntry.remove(function() {
            alert('File removed.');
         }, errorCallback);

      }, errorCallback);
   }

   function errorCallback(error) {
      alert("ERROR: " + error.code)
   }

}   
}



