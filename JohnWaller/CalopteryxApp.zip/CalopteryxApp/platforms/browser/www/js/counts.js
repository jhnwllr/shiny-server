	



document.getElementById("CSM").addEventListener("click", csmClick);
document.getElementById("CVM").addEventListener("click", cvmClick);
document.getElementById("CSF").addEventListener("click", csfClick);
document.getElementById("CVF").addEventListener("click", cvfClick);

document.getElementById("CSM5").addEventListener("click", CSM5);
document.getElementById("CVM5").addEventListener("click", CVM5);



document.getElementById("writeFile").addEventListener("click", writeFile);
document.getElementById("Reset").addEventListener("click", reset);


function reset() {
CSM = 0;
CVM = 0;
CSF = 0;
CVF = 0;

document.getElementById("CSM").innerHTML = "CSM:" + CSM;
document.getElementById("CSF").innerHTML = "CSF:" + CSF;
document.getElementById("CVM").innerHTML = "CVM:" + CVM;
document.getElementById("CVF").innerHTML = "CVF:" + CVF;

}
		
var CSM = 0;
document.getElementById("CSM").innerHTML = "CSM:" + CSM;
function csmClick() {
navigator.vibrate(30);
CSM += 1;
document.getElementById("CSM").innerHTML = "CSM:" + CSM;
};

function CSM5() {
navigator.vibrate(50);
CSM += 5;
document.getElementById("CSM").innerHTML = "CSM:" + CSM;
};



var CVM = 0;
document.getElementById("CVM").innerHTML = "CVM:" + CVM;
function cvmClick() {
navigator.vibrate(30);
CVM += 1;
document.getElementById("CVM").innerHTML = "CVM:" + CVM;
};
function CVM5() {
navigator.vibrate(50);
CVM += 5;
document.getElementById("CVM").innerHTML = "CVM:" + CVM;
};

var CSF = 0;
document.getElementById("CSF").innerHTML = "CSF:" + CSF;
function csfClick() {
navigator.vibrate(30);
CSF += 1;
document.getElementById("CSF").innerHTML = "CSF:" + CSF;
};


var CVF = 0;
document.getElementById("CVF").innerHTML = "CVF:" + CVF;
function cvfClick() {
navigator.vibrate(30);
CVF += 1;
document.getElementById("CVF").innerHTML = "CVF:" + CVF;
};

var fs = require('fs');	

function reset() {
CSM = 0;
CVM = 0;
CSF = 0;
CVF = 0;

document.getElementById("CSM").innerHTML = "CSM:" + CSM;
document.getElementById("CSF").innerHTML = "CSF:" + CSF;
document.getElementById("CVM").innerHTML = "CVM:" + CVM;
document.getElementById("CVF").innerHTML = "CVF:" + CVF;

}


function writeFile() {

var radios = document.getElementsByName('r1');
for (var i = 0, length = radios.length; i < length; i++) {
if (radios[i].checked) {
section = radios[i].value;
break;
}
}

console.log(section);


var dateObj = new Date();
newdate =  dateObj.toLocaleString();

var messageData = "counts" + ";" + section +";"+ CSM +";"+ CVM +";"+ CSF +";"+ CVF+";"+newdate+";"+ "\n";

CSM = 0;
CVM = 0;
CSF = 0;
CVF = 0;

document.getElementById("CSM").innerHTML = "CSM:" + CSM;
document.getElementById("CSF").innerHTML = "CSF:" + CSF;
document.getElementById("CVM").innerHTML = "CVM:" + CVM;
document.getElementById("CVF").innerHTML = "CVF:" + CVF;


var type = window.TEMPORARY;
var size = 5*1024*1024;
window.requestFileSystem(type, size, successCallback, errorCallback)
function successCallback(fs) {

fs.root.getFile('log.txt', {create: true}, function(fileEntry) {


fileEntry.createWriter(function(fileWriter) {
fileWriter.onwriteend = function(e) {
alert('Write completed.');
};

fileWriter.onerror = function(e) {
alert('Write failed: ' + e.toString());
};

var blob = new Blob([messageData], {type: 'text/plain'});
fileWriter.seek(fileWriter.length);
fileWriter.write(blob);
}, errorCallback);

}, errorCallback);

}

function errorCallback(error) {
alert("ERROR: " + error.code)
}

}


function successCallback(fs) {

	fs.root.getFile('log.txt', {}, function(fileEntry) {
	
	fileEntry.file(function(file) {
	var reader = new FileReader();

	reader.onloadend = function(e) {
	var txtArea = document.getElementById('textarea');
	txtArea.value = this.result;
	messageData = this.result;
	console.log(messageData);
	};

    reader.readAsText(file);

    }, errorCallback);
	}, errorCallback);
   
   }

function errorCallback(error) {
  alert("ERROR: " + error.code)
}

